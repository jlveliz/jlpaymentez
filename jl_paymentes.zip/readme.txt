=== Plugin Name ===
Contributors: Jorge Luis Veliz
Website: http://thejlmedia.com/
Requires PHP: 5.2.4
License: GPLv2 or later

== Description ==
Allow make payments with Paymentez 